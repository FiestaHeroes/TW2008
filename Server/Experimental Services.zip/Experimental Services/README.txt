We have introduced a patch that allows running a server on a new operating system, such as Windows Server 2022. However, it is important to note that there have been reports of instability associated with this patch. Therefore, it is advised to exercise caution and be aware of the potential risks before implementing it.

Furthermore, please be aware that the "_Install Databases.ps1" script is not compatible with the backups on a new operating system. Consequently, manual installation of the databases is required. To learn more about the process and obtain detailed instructions, please refer to our setup documentation available at: https://doc.fiestaheroes.com/docs/server_and_client_setup/.

If you need any further clarification or have specific inquiries regarding the setup or related matters, feel free to ask.

Regards,
FH